package com.chacarestaurante.pos;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import androidx.core.content.FileProvider;

public class MainActivity extends Activity {

    private static final String POS_URL =
        "https://script.google.com/a/macros/digitalposapp.com/s/AKfycbzGrKC0dj_KwxrtdbtRqQEELEml91xV6A1j3ZZ7vqG_BAlSK28OG1q8Wm-seu8OCTY6YA/exec";

    private static final String TAG = "ChacaPOS";
    private WebView webView;
    private ProgressBar progressBar;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        RelativeLayout layout = new RelativeLayout(this);
        layout.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT));

        webView = new WebView(this);
        webView.setLayoutParams(new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        RelativeLayout.LayoutParams pbParams = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT, 8);
        pbParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
        progressBar.setLayoutParams(pbParams);
        progressBar.setMax(100);

        layout.addView(webView);
        layout.addView(progressBar);
        setContentView(layout);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.addJavascriptInterface(new PrintBridge(), "AndroidPrint");

        webView.setWebChromeClient(new android.webkit.WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progressBar.setProgress(p);
                if (p == 100) mainHandler.postDelayed(
                    () -> progressBar.setVisibility(View.GONE), 400);
                else progressBar.setVisibility(View.VISIBLE);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Inyectar bridge: reemplaza _descargarTicketBin con impresión directa
                view.evaluateJavascript(
                    "(function(){" +
                    "  function instalarBridge(){" +
                    "    if(typeof _ticketBytesActuales === 'undefined'){" +
                    "      setTimeout(instalarBridge, 500); return;" +
                    "    }" +
                    "    window._descargarTicketBin = function(){" +
                    "      if(!_ticketBytesActuales) return;" +
                    "      try{" +
                    "        var arr = new Uint8Array(_ticketBytesActuales);" +
                    "        var bin = '';" +
                    "        for(var i=0;i<arr.length;i++) bin += String.fromCharCode(arr[i]);" +
                    "        var b64 = btoa(bin);" +
                    "        AndroidPrint.imprimirEscPos(b64);" +
                    "        var m=document.getElementById('_modalTicketPreview');" +
                    "        if(m) m.style.display='none';" +
                    "      }catch(e){ console.error('Bridge:',e); }" +
                    "    };" +
                    "    console.log('ChacaPOS bridge instalado OK');" +
                    "  }" +
                    "  instalarBridge();" +
                    "})();",
                    null
                );
            }
        });

        webView.loadUrl(POS_URL);
    }

    private class PrintBridge {
        @JavascriptInterface
        public void imprimirEscPos(String base64Data) {
            Log.d(TAG, "Imprimiendo " + base64Data.length() + " chars b64");
            try {
                byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);

                File dir = new File(getCacheDir(), "tickets");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, "ticket.bin");
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(bytes);
                }

                Uri uri = FileProvider.getUriForFile(
                    MainActivity.this,
                    "com.chacarestaurante.pos.fileprovider",
                    f
                );

                // Intent directo a RawBT — sin selector, sin diálogos
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, "application/octet-stream");
                intent.setPackage("ru.a402d.rawbtprinter");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                if (getPackageManager().resolveActivity(intent, 0) != null) {
                    startActivity(intent);
                    mainHandler.post(() -> Toast.makeText(
                        MainActivity.this, "Imprimiendo...", Toast.LENGTH_SHORT).show());
                } else {
                    // RawBT no instalado — abrir selector
                    Intent chooser = Intent.createChooser(intent, "Abrir con...");
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(chooser);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error impresion: " + e.getMessage());
                mainHandler.post(() -> Toast.makeText(
                    MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }

        @JavascriptInterface
        public boolean rawBTDisponible() {
            Intent t = new Intent(Intent.ACTION_VIEW);
            t.setPackage("ru.a402d.rawbtprinter");
            return getPackageManager().resolveActivity(t, 0) != null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause()   { super.onPause();   webView.onPause(); }
    @Override protected void onResume()  { super.onResume();  webView.onResume(); }
    @Override protected void onDestroy() { webView.destroy(); super.onDestroy(); }
}
